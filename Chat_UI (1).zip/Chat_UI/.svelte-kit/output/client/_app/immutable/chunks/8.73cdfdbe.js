import{default as t}from"../entry/privacy-page.svelte.e47c38ca.js";export{t as component};
