import{default as t}from"../entry/_error.svelte.e2eee89c.js";export{t as component};
