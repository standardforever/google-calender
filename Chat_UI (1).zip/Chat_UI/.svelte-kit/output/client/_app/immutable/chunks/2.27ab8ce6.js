import{default as t}from"../entry/_page.svelte.0631a180.js";export{t as component};
