import{default as t}from"../entry/r-_id_-page.svelte.2ba7a1ea.js";export{t as component};
