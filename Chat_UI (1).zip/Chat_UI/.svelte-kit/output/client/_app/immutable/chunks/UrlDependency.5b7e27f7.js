const t=!0;var s=(r=>(r.ConversationList="conversation:list",r))(s||{});export{s as U,t as b};
