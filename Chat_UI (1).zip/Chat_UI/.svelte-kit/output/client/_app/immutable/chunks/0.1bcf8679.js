import{default as t}from"../entry/_layout.svelte.1def6cbc.js";export{t as component};
