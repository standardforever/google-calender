function s(a,r){navigator.share?navigator.share({url:a,title:r}):prompt("Copy this public url to share:",a)}export{s};
