import{w as e}from"./singletons.191ba8a2.js";const r=e(null);export{r as p};
