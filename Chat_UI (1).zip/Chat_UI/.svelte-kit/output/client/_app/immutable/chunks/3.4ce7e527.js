import{default as t}from"../entry/conversation-_id_-page.svelte.315c7b73.js";export{t as component};
