import { c as create_ssr_component, b as subscribe, g as escape, v as validate_component } from "../../../../chunks/index3.js";
import { p as pendingMessage, w as webSearchParameters, C as ChatWindow } from "../../../../chunks/pendingMessage.js";
import { p as pendingMessageIdToRetry } from "../../../../chunks/pendingMessageIdToRetry.js";
import { p as page } from "../../../../chunks/stores.js";
import { e as error } from "../../../../chunks/errors.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let title;
  let $page, $$unsubscribe_page;
  let $$unsubscribe_pendingMessageIdToRetry;
  let $$unsubscribe_pendingMessage;
  let $$unsubscribe_error;
  let $$unsubscribe_webSearchParameters;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe_pendingMessageIdToRetry = subscribe(pendingMessageIdToRetry, (value) => value);
  $$unsubscribe_pendingMessage = subscribe(pendingMessage, (value) => value);
  $$unsubscribe_error = subscribe(error, (value) => value);
  $$unsubscribe_webSearchParameters = subscribe(webSearchParameters, (value) => value);
  let { data } = $$props;
  let messages = data.messages;
  let lastLoadedMessages = data.messages;
  let type = data.type;
  let webSearchMessages = [];
  let loading = false;
  let pending = false;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  let $$settled;
  let $$rendered;
  do {
    $$settled = true;
    {
      if (data.messages !== lastLoadedMessages) {
        messages = data.messages;
        lastLoadedMessages = data.messages;
      }
    }
    {
      $page.params.id;
    }
    title = data.conversations.find((conv) => conv.id === $page.params.id)?.title ?? data.title;
    $$rendered = `${$$result.head += `<!-- HEAD_svelte-1az6e94_START -->${$$result.title = `<title>${escape(title)}</title>`, ""}<!-- HEAD_svelte-1az6e94_END -->`, ""}

${validate_component(ChatWindow, "ChatWindow").$$render(
      $$result,
      {
        loading,
        pending,
        messages,
        currentModel: {
          id: "1",
          displayName: "ChatGPT/GPT-3.5-turbo",
          name: "chatgpt"
        },
        settings: data.settings,
        type,
        webSearchMessages
      },
      {
        webSearchMessages: ($$value) => {
          webSearchMessages = $$value;
          $$settled = false;
        }
      },
      {}
    )}`;
  } while (!$$settled);
  $$unsubscribe_page();
  $$unsubscribe_pendingMessageIdToRetry();
  $$unsubscribe_pendingMessage();
  $$unsubscribe_error();
  $$unsubscribe_webSearchParameters();
  return $$rendered;
});
export {
  Page as default
};
