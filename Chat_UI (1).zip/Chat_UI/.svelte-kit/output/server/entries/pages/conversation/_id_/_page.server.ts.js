import { c as collections } from "../../../../chunks/database.js";
import { ObjectId } from "mongodb";
import { e as error } from "../../../../chunks/index.js";
const load = async ({ params }) => {
  const conversation = await collections.conversations.findOne({
    _id: new ObjectId(params.id)
  });
  if (!conversation) {
    throw error(404, "Conversation not found.");
  }
  return {
    messages: conversation.messages,
    title: conversation.title,
    model: conversation.model,
    type: conversation.type
  };
};
export {
  load
};
