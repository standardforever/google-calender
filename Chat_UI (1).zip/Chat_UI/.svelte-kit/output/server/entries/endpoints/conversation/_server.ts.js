import { c as collections } from "../../../chunks/database.js";
import { ObjectId } from "mongodb";
import { e as error, r as redirect } from "../../../chunks/index.js";
import { b as base } from "../../../chunks/paths.js";
import { z } from "zod";
import { v as validateModel, m as models } from "../../../chunks/models.js";
import { a as authCondition } from "../../../chunks/auth.js";
const POST = async ({ locals, request }) => {
  const body = await request.text();
  let title = "";
  let messages = [];
  const values = z.object({
    fromShare: z.string().optional(),
    model: validateModel(models),
    type: z.enum(["pdf", "csv", "agent", "normal"])
  }).parse(JSON.parse(body));
  if (values.fromShare) {
    const conversation = await collections.sharedConversations.findOne({
      _id: values.fromShare
    });
    if (!conversation) {
      throw error(404, "Conversation not found");
    }
    title = conversation.title;
    messages = conversation.messages;
    values.model = conversation.model;
  }
  const res = await collections.conversations.insertOne({
    _id: new ObjectId(),
    title: title || "Untitled " + (await collections.conversations.countDocuments(authCondition(locals)) + 1),
    messages,
    model: values.model,
    type: values.type,
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date(),
    ...locals.user ? { userId: locals.user._id } : { sessionId: locals.sessionId },
    ...values.fromShare ? { meta: { fromShareId: values.fromShare } } : {}
  });
  return new Response(
    JSON.stringify({
      conversationId: res.insertedId.toString()
    }),
    { headers: { "Content-Type": "application/json" } }
  );
};
const GET = async () => {
  throw redirect(302, `${base}/`);
};
export {
  GET,
  POST
};
