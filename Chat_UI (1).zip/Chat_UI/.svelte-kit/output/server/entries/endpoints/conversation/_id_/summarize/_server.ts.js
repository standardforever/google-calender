import { b as buildPrompt } from "../../../../../chunks/buildPrompt.js";
import { a as authCondition } from "../../../../../chunks/auth.js";
import { c as collections } from "../../../../../chunks/database.js";
import { g as generateFromDefaultEndpoint } from "../../../../../chunks/generateFromDefaultEndpoint.js";
import { d as defaultModel } from "../../../../../chunks/models.js";
import { e as error } from "../../../../../chunks/index.js";
import { ObjectId } from "mongodb";
async function POST({ params, locals }) {
  const convId = new ObjectId(params.id);
  const conversation = await collections.conversations.findOne({
    _id: convId,
    ...authCondition(locals)
  });
  if (!conversation) {
    throw error(404, "Conversation not found");
  }
  const firstMessage = conversation.messages.find((m) => m.from === "user");
  const userPrompt = `Please summarize the following message as a single sentence of less than 5 words:
` + firstMessage?.content;
  const prompt = await buildPrompt([{ from: "user", content: userPrompt }], defaultModel);
  const generated_text = await generateFromDefaultEndpoint(prompt);
  if (generated_text) {
    await collections.conversations.updateOne(
      {
        _id: convId,
        ...authCondition(locals)
      },
      {
        $set: { title: generated_text }
      }
    );
  }
  return new Response(
    JSON.stringify(
      generated_text ? {
        title: generated_text
      } : {}
    ),
    { headers: { "Content-Type": "application/json" } }
  );
}
export {
  POST
};
