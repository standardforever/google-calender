import { b as base } from "../../../../../chunks/paths.js";
import { a as authCondition } from "../../../../../chunks/auth.js";
import { c as collections } from "../../../../../chunks/database.js";
import { s as sha256 } from "../../../../../chunks/sha256.js";
import { e as error } from "../../../../../chunks/index.js";
import { ObjectId } from "mongodb";
import { nanoid } from "nanoid";
async function POST({ params, url, locals }) {
  const conversation = await collections.conversations.findOne({
    _id: new ObjectId(params.id),
    ...authCondition(locals)
  });
  if (!conversation) {
    throw error(404, "Conversation not found");
  }
  const hash = await sha256(JSON.stringify(conversation.messages));
  const existingShare = await collections.sharedConversations.findOne({ hash });
  if (existingShare) {
    return new Response(
      JSON.stringify({
        url: getShareUrl(url, existingShare._id)
      }),
      { headers: { "Content-Type": "application/json" } }
    );
  }
  const shared = {
    _id: nanoid(7),
    createdAt: /* @__PURE__ */ new Date(),
    messages: conversation.messages,
    hash,
    updatedAt: /* @__PURE__ */ new Date(),
    title: conversation.title,
    model: conversation.model
  };
  await collections.sharedConversations.insertOne(shared);
  return new Response(
    JSON.stringify({
      url: getShareUrl(url, shared._id)
    }),
    { headers: { "Content-Type": "application/json" } }
  );
}
function getShareUrl(url, shareId) {
  return `${`${url.origin}${base}`}/r/${shareId}`;
}
export {
  POST
};
