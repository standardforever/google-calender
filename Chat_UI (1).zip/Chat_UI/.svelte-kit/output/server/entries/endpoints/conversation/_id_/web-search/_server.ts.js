import { a as authCondition } from "../../../../../chunks/auth.js";
import { c as collections } from "../../../../../chunks/database.js";
import { g as generateFromDefaultEndpoint } from "../../../../../chunks/generateFromDefaultEndpoint.js";
import { d as defaultModel } from "../../../../../chunks/models.js";
import { S as SERPAPI_KEY } from "../../../../../chunks/private.js";
import { getJson } from "serpapi";
import { e as error } from "../../../../../chunks/index.js";
import { ObjectId } from "mongodb";
import { z } from "zod";
import { VirtualConsole, JSDOM } from "jsdom";
async function searchWeb(query) {
  const params = {
    q: query,
    hl: "en",
    gl: "us",
    google_domain: "google.com",
    api_key: SERPAPI_KEY
  };
  const response = await getJson("google", params);
  return response;
}
function removeTags(node) {
  if (node.hasChildNodes()) {
    node.childNodes.forEach((childNode) => {
      if (node.nodeName === "SCRIPT" || node.nodeName === "STYLE") {
        node.removeChild(childNode);
      } else {
        removeTags(childNode);
      }
    });
  }
}
function naiveInnerText(node) {
  const Node = node;
  return [...node.childNodes].map((childNode) => {
    switch (childNode.nodeType) {
      case Node.TEXT_NODE:
        return node.textContent;
      case Node.ELEMENT_NODE:
        return naiveInnerText(childNode);
      default:
        return "";
    }
  }).join("\n");
}
function removeLinks(obj) {
  for (const prop in obj) {
    if (prop.endsWith("link"))
      delete obj[prop];
    else if (typeof obj[prop] === "object")
      removeLinks(obj[prop]);
  }
  return obj;
}
async function GET({ params, locals, url }) {
  const model = defaultModel;
  const convId = new ObjectId(params.id);
  const searchId = new ObjectId();
  const conv = await collections.conversations.findOne({
    _id: convId,
    ...authCondition(locals)
  });
  if (!conv) {
    throw error(404, "Conversation not found");
  }
  const prompt = z.string().trim().min(1).parse(url.searchParams.get("prompt"));
  const messages = (() => {
    return [...conv.messages, { content: prompt, from: "user", id: crypto.randomUUID() }];
  })();
  const stream = new ReadableStream({
    async start(controller) {
      const webSearch = {
        _id: searchId,
        convId,
        prompt,
        searchQuery: "",
        knowledgeGraph: "",
        results: [],
        summary: "",
        messages: [],
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      };
      try {
        webSearch.messages.push({
          type: "update",
          message: "Generating search query"
        });
        controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
        const promptSearchQuery = model.userMessageToken + "The following messages were written by a user, trying to answer a question." + model.messageEndToken + messages.filter((message) => message.from === "user").map((message) => model.userMessageToken + message.content + model.messageEndToken) + model.userMessageToken + "What plain-text english sentence would you input into Google to answer the last question? Answer with a short (10 words max) simple sentence." + model.messageEndToken + model.assistantMessageToken + "Query: ";
        webSearch.searchQuery = await generateFromDefaultEndpoint(promptSearchQuery).then(
          (query) => {
            const arr = query.split(/\r?\n/);
            return arr[0].length > 0 ? arr[0] : arr[1];
          }
        );
        webSearch.messages.push({
          type: "update",
          message: "Searching Google",
          args: [webSearch.searchQuery]
        });
        controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
        const results = await searchWeb(webSearch.searchQuery);
        let text = "";
        webSearch.results = (results.organic_results && results.organic_results.map((el) => el.link)) ?? [];
        if (results.knowledge_graph) {
          webSearch.knowledgeGraph = JSON.stringify(removeLinks(results.knowledge_graph));
          text = webSearch.knowledgeGraph;
          webSearch.messages.push({
            type: "update",
            message: "Found a Google knowledge page"
          });
          controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
        } else if (webSearch.results.length > 0) {
          const topUrl = webSearch.results[0];
          webSearch.messages.push({
            type: "update",
            message: "Browsing first result",
            args: [JSON.stringify(topUrl)]
          });
          controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
          const abortController = new AbortController();
          setTimeout(() => abortController.abort(), 1e4);
          const htmlString = await fetch(topUrl, { signal: abortController.signal }).then((response) => response.text()).catch((err) => console.log(err));
          const virtualConsole = new VirtualConsole();
          virtualConsole.on("error", () => {
          });
          const dom = new JSDOM(htmlString ?? "", {
            virtualConsole
          });
          const body = dom.window.document.querySelector("body");
          if (!body)
            throw new Error("body of the webpage is null");
          removeTags(body);
          text = (naiveInnerText(body) ?? "").replace(/ {2}|\r\n|\n|\r/gm, "");
          if (!text)
            throw new Error("text of the webpage is null");
        } else {
          throw new Error("No results found for this search query");
        }
        webSearch.messages.push({
          type: "update",
          message: "Creating summary"
        });
        controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
        const summaryPrompt = model.userMessageToken + text.split(" ").slice(0, model.parameters?.truncate ?? 0).join(" ") + model.messageEndToken + model.userMessageToken + `The text above should be summarized to best answer the query: ${webSearch.searchQuery}.` + model.messageEndToken + model.assistantMessageToken + "Summary: ";
        webSearch.summary = await generateFromDefaultEndpoint(summaryPrompt).then(
          (txt) => txt.trim()
        );
        webSearch.messages.push({
          type: "update",
          message: "Injecting summary",
          args: [JSON.stringify(webSearch.summary)]
        });
        controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
      } catch (searchError) {
        if (searchError instanceof Error) {
          webSearch.messages.push({
            type: "error",
            message: "An error occurred with the web search",
            args: [JSON.stringify(searchError.message)]
          });
        }
      }
      const res = await collections.webSearches.insertOne(webSearch);
      webSearch.messages.push({
        type: "result",
        id: res.insertedId.toString()
      });
      controller.enqueue(JSON.stringify({ messages: webSearch.messages }));
    }
  });
  return new Response(stream, { headers: { "Content-Type": "application/json" } });
}
export {
  GET
};
