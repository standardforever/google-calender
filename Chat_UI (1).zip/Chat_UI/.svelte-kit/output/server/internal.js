import { g, o, a, b, s } from "./chunks/internal.js";
import { s as s2 } from "./chunks/paths.js";
export {
  g as get_hooks,
  o as options,
  s2 as set_assets,
  a as set_building,
  b as set_private_env,
  s as set_public_env
};
