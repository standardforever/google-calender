

export const index = 1;
export const component = async () => (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["_app/immutable/entry/_error.svelte.e2eee89c.js","_app/immutable/chunks/index.0f8dcc8b.js","_app/immutable/chunks/stores.8786bc7c.js","_app/immutable/chunks/singletons.191ba8a2.js"];
export const stylesheets = [];
export const fonts = [];
