import * as server from '../entries/pages/_layout.server.ts.js';

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/+layout.server.ts";
export const imports = ["_app/immutable/entry/_layout.svelte.1def6cbc.js","_app/immutable/chunks/index.0f8dcc8b.js","_app/immutable/chunks/LoginModal.7c96819f.js","_app/immutable/chunks/singletons.191ba8a2.js","_app/immutable/chunks/parse.d12b0d5b.js","_app/immutable/chunks/stores.8786bc7c.js","_app/immutable/chunks/share.4f3afad4.js","_app/immutable/chunks/UrlDependency.5b7e27f7.js"];
export const stylesheets = ["_app/immutable/assets/_layout.705eba18.css"];
export const fonts = [];
