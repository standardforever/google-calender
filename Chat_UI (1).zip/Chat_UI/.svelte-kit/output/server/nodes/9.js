import * as server from '../entries/pages/r/_id_/_page.server.ts.js';

export const index = 9;
export const component = async () => (await import('../entries/pages/r/_id_/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/r/[id]/+page.server.ts";
export const imports = ["_app/immutable/entry/r-_id_-page.svelte.2ba7a1ea.js","_app/immutable/chunks/index.0f8dcc8b.js","_app/immutable/chunks/LoginModal.7c96819f.js","_app/immutable/chunks/singletons.191ba8a2.js","_app/immutable/chunks/parse.d12b0d5b.js","_app/immutable/chunks/stores.8786bc7c.js","_app/immutable/chunks/pendingMessage.9cb6be8e.js","_app/immutable/chunks/marked.esm.76161808.js","_app/immutable/chunks/preload-helper.41c905a7.js","_app/immutable/chunks/pendingMessageIdToRetry.8f8e21c5.js","_app/immutable/chunks/share.4f3afad4.js"];
export const stylesheets = ["_app/immutable/assets/pendingMessage.ba0dfcb8.css"];
export const fonts = [];
