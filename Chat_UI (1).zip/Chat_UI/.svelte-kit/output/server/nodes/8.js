

export const index = 8;
export const component = async () => (await import('../entries/pages/privacy/_page.svelte.js')).default;
export const imports = ["_app/immutable/entry/privacy-page.svelte.e47c38ca.js","_app/immutable/chunks/index.0f8dcc8b.js","_app/immutable/chunks/marked.esm.76161808.js"];
export const stylesheets = [];
export const fonts = [];
