import * as server from '../entries/pages/login/_page.server.ts.js';

export const index = 5;
export { server };
export const server_id = "src/routes/login/+page.server.ts";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
