import * as server from '../entries/pages/login/callback/_page.server.ts.js';

export const index = 6;
export { server };
export const server_id = "src/routes/login/callback/+page.server.ts";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
