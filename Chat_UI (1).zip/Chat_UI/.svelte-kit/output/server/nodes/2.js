

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/entry/_page.svelte.0631a180.js","_app/immutable/chunks/index.0f8dcc8b.js","_app/immutable/chunks/LoginModal.7c96819f.js","_app/immutable/chunks/singletons.191ba8a2.js","_app/immutable/chunks/parse.d12b0d5b.js","_app/immutable/chunks/pendingMessage.9cb6be8e.js","_app/immutable/chunks/stores.8786bc7c.js","_app/immutable/chunks/marked.esm.76161808.js","_app/immutable/chunks/preload-helper.41c905a7.js"];
export const stylesheets = ["_app/immutable/assets/pendingMessage.ba0dfcb8.css"];
export const fonts = [];
