import { c as collections } from "./database.js";
import { ObjectId } from "mongodb";
async function buildPrompt(messages, model, webSearchId) {
  const prompt = messages.map(
    (m) => (m.from === "user" ? model.userMessageToken + m.content : model.assistantMessageToken + m.content) + (model.messageEndToken ? m.content.endsWith(model.messageEndToken) ? "" : model.messageEndToken : "")
  ).join("") + model.assistantMessageToken;
  if (webSearchId) {
    const webSearch = await collections.webSearches.findOne({
      _id: new ObjectId(webSearchId)
    });
    if (!webSearch)
      throw new Error("Web search not found");
    if (webSearch.summary) {
      model.assistantMessageToken + `The following context was found while searching the internet: ${webSearch.summary}` + model.messageEndToken;
    }
  }
  const finalPrompt = prompt.split(" ").slice(-(model.parameters?.truncate ?? 0)).join(" ");
  return finalPrompt;
}
export {
  buildPrompt as b
};
