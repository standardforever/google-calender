import { d as defaultModel } from "./models.js";
import { H as HF_ACCESS_TOKEN } from "./private.js";
import { textGeneration } from "@huggingface/inference";
import { P as PUBLIC_SEP_TOKEN } from "./publicSepToken.js";
function sum(nums) {
  return nums.reduce((a, b) => a + b, 0);
}
function modelEndpoint(model) {
  if (!model.endpoints) {
    return {
      url: `https://api-inference.huggingface.co/models/${model.name}`,
      authorization: `Bearer ${HF_ACCESS_TOKEN}`,
      weight: 1
    };
  }
  const endpoints = model.endpoints;
  const totalWeight = sum(endpoints.map((e) => e.weight));
  let random = Math.random() * totalWeight;
  for (const endpoint of endpoints) {
    if (random < endpoint.weight) {
      return endpoint;
    }
    random -= endpoint.weight;
  }
  throw new Error("Invalid config, no endpoint found");
}
function trimSuffix(input, end) {
  if (input.endsWith(end)) {
    return input.slice(0, input.length - end.length);
  }
  return input;
}
function trimPrefix(input, prefix) {
  if (input.startsWith(prefix)) {
    return input.slice(prefix.length);
  }
  return input;
}
async function generateFromDefaultEndpoint(prompt, parameters) {
  const newParameters = {
    ...defaultModel.parameters,
    ...parameters,
    return_full_text: false
  };
  const endpoint = modelEndpoint(defaultModel);
  let { generated_text } = await textGeneration(
    {
      model: endpoint.url,
      inputs: prompt,
      parameters: newParameters
    },
    {
      fetch: (url, options) => fetch(url, {
        ...options,
        headers: { ...options?.headers, Authorization: endpoint.authorization }
      })
    }
  );
  generated_text = trimSuffix(trimPrefix(generated_text, "<|startoftext|>"), PUBLIC_SEP_TOKEN);
  return generated_text;
}
export {
  generateFromDefaultEndpoint as g
};
