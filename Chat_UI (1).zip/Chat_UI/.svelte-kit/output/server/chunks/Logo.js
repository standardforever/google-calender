import { c as create_ssr_component, f as add_attribute } from "./index3.js";
const Logo = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { classNames = "" } = $$props;
  if ($$props.classNames === void 0 && $$bindings.classNames && classNames !== void 0)
    $$bindings.classNames(classNames);
  return `<img width="22px" height="22px"${add_attribute("class", classNames, 0)} src="/favicon.png" alt="Logo">`;
});
export {
  Logo as L
};
