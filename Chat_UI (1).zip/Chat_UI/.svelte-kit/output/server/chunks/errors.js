import { w as writable } from "./index2.js";
const PUBLIC_ORIGIN = "";
const PUBLIC_GOOGLE_ANALYTICS_ID = "";
const PUBLIC_DEPRECATED_GOOGLE_ANALYTICS_ID = "";
const PUBLIC_ANNOUNCEMENT_BANNERS = '[\n  {\n    "title": "Chat UI is now open sourced on GitHub",\n    "linkTitle": "GitHub repo",\n    "linkHref": "https://github.com/huggingface/chat-ui"\n  }\n]';
const ERROR_MESSAGES = {
  default: "Oops, something went wrong.",
  authOnly: "You have to be logged in."
};
const error = writable(null);
export {
  ERROR_MESSAGES as E,
  PUBLIC_ORIGIN as P,
  PUBLIC_ANNOUNCEMENT_BANNERS as a,
  PUBLIC_GOOGLE_ANALYTICS_ID as b,
  PUBLIC_DEPRECATED_GOOGLE_ANALYTICS_ID as c,
  error as e
};
