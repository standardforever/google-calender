import { w as writable } from "./index2.js";
const pendingMessageIdToRetry = writable(null);
export {
  pendingMessageIdToRetry as p
};
