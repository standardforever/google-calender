import { D as DEV, B as BROWSER } from "./prod-ssr.js";
const browser = BROWSER;
const dev = DEV;
export {
  browser as b,
  dev as d
};
