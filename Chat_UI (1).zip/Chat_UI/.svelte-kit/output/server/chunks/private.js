const MONGODB_URL = "mongodb+srv://jimmythepad:j4H5KiTwUwq5jC8n@inqdata.fvtuu8u.mongodb.net/?retryWrites=true&w=majority";
const MONGODB_DB_NAME = "inqdata";
const MONGODB_DIRECT_CONNECTION = "false";
const COOKIE_NAME = "hf-chat";
const HF_ACCESS_TOKEN = "";
const SERPAPI_KEY = "";
const OPENID_CLIENT_ID = "";
const OPENID_CLIENT_SECRET = "";
const OPENID_SCOPES = "openid profile";
const OPENID_PROVIDER_URL = "https://huggingface.co";
const MODELS = `[
  {
    "name": "OpenAssistant/oasst-sft-4-pythia-12b-epoch-3.5",
    "datasetName": "OpenAssistant/oasst1",
    "description": "A good alternative to ChatGPT",
    "websiteUrl": "https://open-assistant.io",
    "userMessageToken": "<|prompter|>",
    "assistantMessageToken": "<|assistant|>",
    "messageEndToken": "</s>",
    "preprompt": "Below are a series of dialogues between various people and an AI assistant. The AI tries to be helpful, polite, honest, sophisticated, emotionally aware, and humble-but-knowledgeable. The assistant is happy to help with almost anything, and will do its best to understand exactly what is needed. It also tries to avoid giving false or misleading information, and it caveats when it isn't entirely sure about the right answer. That said, the assistant is practical and really does its best, and doesn't let caution get too much in the way of being useful.\\n-----\\n",
    "promptExamples": [
      {
        "title": "Write an email from bullet list",
        "prompt": "As a restaurant owner, write a professional email to the supplier to get these products every week: \\n\\n- Wine (x10)\\n- Eggs (x24)\\n- Bread (x12)"
      }, {
        "title": "Code a snake game",
        "prompt": "Code a basic snake game in python, give explanations for each step."
      }, {
        "title": "Assist in a task",
        "prompt": "How do I make a delicious lemon cheesecake?"
      }
    ],
    "parameters": {
      "temperature": 0.9,
      "top_p": 0.95,
      "repetition_penalty": 1.2,
      "top_k": 50,
      "truncate": 1000,
      "max_new_tokens": 1024
    }
  }
]`;
const OLD_MODELS = "[]";
export {
  COOKIE_NAME as C,
  HF_ACCESS_TOKEN as H,
  MODELS as M,
  OLD_MODELS as O,
  SERPAPI_KEY as S,
  OPENID_SCOPES as a,
  OPENID_PROVIDER_URL as b,
  OPENID_CLIENT_ID as c,
  OPENID_CLIENT_SECRET as d,
  MONGODB_URL as e,
  MONGODB_DIRECT_CONNECTION as f,
  MONGODB_DB_NAME as g
};
