<script lang="ts">
	import { goto } from "$app/navigation";
	import { base } from "$app/paths";
	import ChatWindow from "$lib/components/chat/ChatWindow.svelte";
	import { ERROR_MESSAGES, error } from "$lib/stores/errors";
	import { pendingMessage } from "$lib/stores/pendingMessage";

	export let data;

	let loading = false;

	async function createConversation(message: string, type: string = "normal") {
		try {
			const res = await fetch(`${base}/conversation`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ model: data.settings.activeModel, type }),
			});

			if (!res.ok) {
				error.set("Error while creating conversation, try again.");
				console.error("Error while creating conversation: " + (await res.text()));
				return;
			}

			const { conversationId } = await res.json();

			// Ugly hack to use a store as temp storage, feel free to improve ^^
			if (type === "normal") pendingMessage.set(message);
			await goto(`${base}/conversation/${conversationId}`, { invalidateAll: true });
		} catch (err) {
			error.set(ERROR_MESSAGES.default);
			console.error(err);
		}
	}
</script>

<ChatWindow
	on:type={(ev) => createConversation("", ev.detail)}
	on:message={(ev) => createConversation(ev.detail)}
	{loading}
	settings={data.settings}
	currentModel={{
		id: 'ChatGPT/GPT-3.5-turbo',
		displayName: "ChatGPT/GPT-3.5-turbo",
		name: "ChatGPT/GPT-3.5-turbo",
	}}
/>
