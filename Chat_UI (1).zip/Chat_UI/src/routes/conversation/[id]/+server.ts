import { authCondition } from "$lib/server/auth";
import { collections } from "$lib/server/database";
import type { Message } from "$lib/types/Message";
import { error } from "@sveltejs/kit";
import { ObjectId } from "mongodb";
import { z } from "zod";
import { RetrievalQAChain, loadQAChain } from "langchain/chains";
import { PineconeStore } from "langchain/vectorstores/pinecone";
import { OpenAIEmbeddings } from "langchain/embeddings/openai";
import { index } from "$lib/server/pinecone";
import { OpenAI } from "langchain/llms";
import { ChatOpenAI } from "langchain/chat_models/openai";
import { streamToAsyncIterable } from "$lib/utils/streamToAsyncIterable";
import { abortedGenerations } from "$lib/server/abortedGenerations";

const openAIApiKey = "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";

const embed = new OpenAIEmbeddings({
	modelName: "text-embedding-ada-002",
	openAIApiKey,
});

const secStore = new PineconeStore(embed, {
	textKey: "text",
	pineconeIndex: index,
	namespace: "sec",
});

const csvStore = new PineconeStore(embed, {
	textKey: "page_content",
	pineconeIndex: index,
});

export async function POST({ request, locals, params }) {
	const id = z.string().parse(params.id);
	const convId = new ObjectId(id);
	const date = new Date();

	const conv = await collections.conversations.findOne({
		_id: convId,
		...authCondition(locals),
	});

	if (!conv) {
		throw error(404, "Conversation not found");
	}

	const json = await request.json();
	const {
		inputs: newPrompt,
		options: { web_search_id, response_id: responseId, is_retry, id: messageId },
	} = z
		.object({
			inputs: z.string().trim().min(1),
			options: z.object({
				id: z.optional(z.string().uuid()),
				response_id: z.optional(z.string().uuid()),
				is_retry: z.optional(z.boolean()),
				web_search_id: z.ostring(),
			}),
		})
		.parse(json);

	const abortController = new AbortController();

	const readableStream = new ReadableStream<string>({
		async start(controller) {
			const llm = new OpenAI({
				temperature: 0,
				openAIApiKey,
				streaming: true,
				callbacks: [
					{
						handleLLMNewToken: async (token: string) => controller.enqueue(token),
					},
				],
			});

			if (conv.type === "pdf") {
				const chain = loadQAChain(llm, {
					type: "stuff",
				});

				const docs = await secStore.similaritySearch(newPrompt, 5);

				await chain.call({
					input_documents: docs,
					question: newPrompt,
				});
			} else if (conv.type === "csv") {
				const chat = new ChatOpenAI({
					temperature: 0,
					openAIApiKey,
					streaming: true,
					callbacks: [
						{
							handleLLMNewToken: async (token: string) => controller.enqueue(token),
						},
					],
				});

				const chain = RetrievalQAChain.fromLLM(chat, csvStore.asRetriever());

				await chain.call({
					query: newPrompt,
				});
			} else if (conv.type === "normal") {
				const prompt =
					`Below are a series of dialogues between various people and an AI assistant. The AI tries to be helpful, polite, honest, sophisticated, emotionally aware, and humble-but-knowledgeable. The assistant is happy to help with almost anything, and will do its best to understand exactly what is needed. It also tries to avoid giving false or misleading information, and it caveats when it isn't entirely sure about the right answer. That said, the assistant is practical and really does its best, and doesn't let caution get too much in the way of being useful.\n-----\n` +
					conv.messages
						.slice(-3)
						.map((m) => (m.from === "user" ? "[User: " + m.content : "[AI: " + m.content) + "]\n")
						.join("");

				await llm.call(prompt + newPrompt);
			} else {
				const response = await fetch("http://127.0.0.1:5000/query-agent", {
					method: "POST",
					signal: abortController.signal,
					headers: {
						"Content-Type": "application/json",
					},
					keepalive: true,
					body: JSON.stringify({
						query: newPrompt,
					}),
				});

				// get response as stream and pipe to controller
				const body = response.body;

				if (!body) throw new Error("No body");

				const reader = body.getReader();
				const decoder = new TextDecoder();
				let res = await reader.read();

				while (res.value && !res.done) {
					res = await reader.read();
					controller.enqueue(decoder.decode(res.value));
				}
			}

			controller.close();
		},
	});

	const [stream1, stream2] = readableStream.tee();

	const messages = (() => {
		if (is_retry && messageId) {
			let retryMessageIdx = conv.messages.findIndex((message) => message.id === messageId);
			if (retryMessageIdx === -1) {
				retryMessageIdx = conv.messages.length;
			}
			return [
				...conv.messages.slice(0, retryMessageIdx),
				{ content: newPrompt, from: "user", id: messageId as Message["id"] },
			];
		}
		return [
			...conv.messages,
			{ content: newPrompt, from: "user", id: (messageId as Message["id"]) || crypto.randomUUID() },
		];
	})() satisfies Message[];

	async function saveMessage() {
		const generated_text = await parseGeneratedText(stream2, convId, date, abortController);

		messages.push({
			from: "assistant",
			content: generated_text,
			webSearchId: web_search_id,
			id: (responseId as Message["id"]) || crypto.randomUUID(),
		});

		await collections.conversations.updateOne(
			{
				_id: convId,
			},
			{
				$set: {
					messages,
					updatedAt: new Date(),
				},
			}
		);
	}

	saveMessage().catch(console.error);

	return new Response(stream1);
}

export async function DELETE({ locals, params }) {
	const convId = new ObjectId(params.id);

	const conv = await collections.conversations.findOne({
		_id: convId,
		...authCondition(locals),
	});

	if (!conv) {
		throw error(404, "Conversation not found");
	}

	await collections.conversations.deleteOne({ _id: conv._id });

	return new Response();
}

export async function PATCH({ request, locals, params }) {
	const { title } = z
		.object({ title: z.string().trim().min(1).max(100) })
		.parse(await request.json());

	const convId = new ObjectId(params.id);

	const conv = await collections.conversations.findOne({
		_id: convId,
		...authCondition(locals),
	});

	if (!conv) {
		throw error(404, "Conversation not found");
	}

	await collections.conversations.updateOne(
		{
			_id: convId,
		},
		{
			$set: {
				title,
			},
		}
	);

	return new Response();
}

async function parseGeneratedText(
	stream: ReadableStream,
	conversationId: ObjectId,
	promptedAt: Date,
	abortController: AbortController
): Promise<string> {
	const inputs: string[] = [];

	for await (const input of streamToAsyncIterable(stream)) {
		inputs.push(input as unknown as string);

		const date = abortedGenerations.get(conversationId.toString());

		if (date && date > promptedAt) {
			abortController.abort("Cancelled by user");

			return inputs.join(" ");
		}
	}

	return inputs.join(" ");
}
