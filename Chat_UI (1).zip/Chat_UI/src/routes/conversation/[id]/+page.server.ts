import { collections } from "$lib/server/database";
import { ObjectId } from "mongodb";
import { error } from "@sveltejs/kit";

export const load = async ({ params }) => {
	// todo: add validation on params.id
	const conversation = await collections.conversations.findOne({
		_id: new ObjectId(params.id),
	});

	if (!conversation) {
		throw error(404, "Conversation not found.");
	}

	return {
		messages: conversation.messages,
		title: conversation.title,
		model: conversation.model,
		type: conversation.type,
	};
};
