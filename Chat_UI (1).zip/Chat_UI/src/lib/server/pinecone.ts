import { PineconeClient } from "@pinecone-database/pinecone";

const pinecone = new PineconeClient();

await pinecone.init({
	environment: "northamerica-northeast1-gcp",
	apiKey: "9379013d-9284-4982-931c-35a51b4f76fd",
});

const index_name = "inqdata";
const indexes = await pinecone.listIndexes();

if (!indexes.includes(index_name)) {
	pinecone.createIndex({
		createRequest: {
			name: index_name,
			dimension: 1536,
			metric: "dotproduct",
		},
	});
}

const index = pinecone.Index(index_name);

export { pinecone, index };
