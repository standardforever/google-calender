/* eslint-disable no-shadow */
export enum UrlDependency {
	ConversationList = "conversation:list",
}
