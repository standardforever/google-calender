<script lang="ts">
	export let classNames = "";
</script>
<img 	
	width="22px"
	height="22px"
	class={classNames} src="/favicon.png"
	alt="Logo"
/>
